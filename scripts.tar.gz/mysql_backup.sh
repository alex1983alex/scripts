#!/bin/bash

mkdir /home/alex/backup-$(date +"%d-%m-%y")
tables=`mysql --skip-column-names -e "use wiki_db; show tables;"`
for table in $tables
 do
     mysqldump -uroot wiki_db $table > /home/alex/backup-$(date +"%d-%m-%y")/wiki_db-$table-$(date +"%d-%m-%y").sql
 done








