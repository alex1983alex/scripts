копирование скриптов из github
В домашней папке пользователя 
sudo git clone https://github.com/alex1983alex/scripts.git
cd scripts
sudo tar -zxvf scripts.tar.gz 

Статические IP
_____________
для каждого сервера в папке ip есть скрипт настройки статического ip-адреса
ip/ip_nginx.sh  (110.20.1.60) - Сервер NGINX
ip/ip_apache1.sh  (110.20.1.61) - Сервер Apache -1
ip/ip_apache2.sh  (110.20.1.62) - Сервер Apache -2
ip/ip_mysql1.sh  (110.20.1.63) - Сервер mysql master
ip/ip_mysql2.sh  (110.20.1.64) - Сервер mysql slave
ip/ip_prom.sh  (110.20.1.66) - Сервер Prometheus


Сервер nginx
__________
Запустить скрипт nginx.sh от root
sudo bash scripts/nginx.sh

Скрипт переименует сервер, установит и настроит nginx, node_exporter, nginx_exporter


Сервер Apache1
_____________
Запустить скрипт apache1.sh от root
sudo bash scripts/apache1.sh

Скрипт переименует сервер, установит и настроит apache (порт 8080), node_exporter


Сервер Apache2
_____________
Запустить скрипт apache2.sh от root
sudo bash scripts/apache2.sh

Скрипт переименует сервер, установит и настроит apache (порт 8081), node_exporter


Сервер mysql master
_________________
Запустить скрипт mysql1.sh от root
sudo bash scripts/mysql1.sh

Скрипт переименует сервер, установит mysql, node_exporter
выведет show master status

далее необходимо настроить сервер mysql slave
восстанавливаем из бэкапа базу даттых test_db (бэкап лежит в папке mysql )
sudo bash scripts/mysql_restore.sh



Сервер mysql slave
________________
Отредактировать скрипт mysql2.sh
nano scripts/mysql2.sh
в строке
mysql -e "CHANGE MASTER TO MASTER_HOST='110.20.1.63', MASTER_USER='repl', MASTER_PASSWORD='replREPL@', MASTER_LOG_FILE='binlog.000004', MASTER_LOG_POS=1006, GET_MASTER_PUBLIC_KEY = 1;"
исправить MASTER_LOG_FILE и MASTER_LOG_POS взяв данные с master сервера

Запустить скрипт mysql2.sh от root
sudo bash scripts/mysql2.sh

Скрипт переименует сервер, установит и настроит mysql, node_exporter
настроит репликацию и создаст задачу в cron на создание потабличных бэкапов в 10:00 ежедневно

 

Сервер Prometheus
_____________
Запустить скрипт prom.sh от root
sudo bash scripts/prom.sh

Скрипт переименует сервер, установит и настроит Prometheus, node_exporter, grafana
Prometheus http://110.20.1.66:9090/
grafana http://110.20.1.66:3000/
дашборды
 node_exporter  -  11074
 nginx_exporter  -  12708






  


  