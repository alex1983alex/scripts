#!/bin/bash

echo 'Установка имени сервера'
#cat >/etc/hostname <<EOL
#ubuntu-apache2
#EOL
hostnamectl set-hostname ubuntu-apache2

echo 'Установка Apache'
apt-get install apache2 --yes
apt-get install php php-mysql libapache2-mod-php php-xml php-mbstring php-intl --yes

#echo 'Установка порта 8081 '
#cp /home/alex/scripts/apache/ports2.conf /etc/apache2/ports.conf
#cp /home/alex/scripts/apache/000-default2.conf /etc/apache2/sites-available/000-default.conf
#echo 'Стартовая страница'
#cp /home/alex/scripts/apache/index2.html /var/www/html/index.html
echo 'Установка wiki'

wget https://releases.wikimedia.org/mediawiki/1.40/mediawiki-1.40.0.tar.gz
tar -zxf /home/alex/mediawiki-1.40.0.tar.gz
rm -f /var/www/html/index.html
cp -r /home/alex/mediawiki-1.40.0/* /var/www/html/
cp -v /home/alex/scripts/apache/LocalSettings2.php /var/www/html/LocalSettings.php

echo 'Старт  apache'
systemctl enable --now  apache2.service
sleep 2
systemctl restart apache2.service

echo 'Установка node_exporter'
wget https://github.com/prometheus/node_exporter/releases/download/v1.6.1/node_exporter-1.6.1.linux-amd64.tar.gz -P /home/alex/monitoring
tar -xvf /home/alex/monitoring/node_exporter-1.6.1.linux-amd64.tar.gz -C /home/alex/monitoring

useradd --no-create-home --shell /usr/sbin/nologon node_exporter

cp -vr /home/alex/monitoring/node_exporter-1.6.1.linux-amd64/node_exporter /usr/local/bin


chown -v -R node_exporter: /usr/local/bin/node_exporter

cp -v /home/alex/scripts/nginx/node_exporter.service /etc/systemd/system

systemctl enable --now node_exporter.service
sleep 2
systemctl status node_exporter.service

echo 'проверка состояния  apache'
systemctl status apache2.service



