#!/bin/bash

echo 'Установка имени сервера'
#cat >/etc/hostname <<EOL
#ubuntu-mysql-slave
#EOL
hostnamectl set-hostname ubuntu-mysql-slave

echo 'Установка mysql'
apt-get install mysql-server mysql-client --yes
cp -v /home/alex/scripts/mysql/mysqld2.cnf /etc/mysql/mysql.conf.d/mysqld.cnf

systemctl restart mysql.service

echo 'Установка node_exporter'
wget https://github.com/prometheus/node_exporter/releases/download/v1.6.1/node_exporter-1.6.1.linux-amd64.tar.gz -P /home/alex/monitoring
tar -xvf /home/alex/monitoring/node_exporter-1.6.1.linux-amd64.tar.gz -C /home/alex/monitoring
useradd --no-create-home --shell /usr/sbin/nologon node_exporter
cp -vr /home/alex/monitoring/node_exporter-1.6.1.linux-amd64/node_exporter /usr/local/bin
chown -v -R node_exporter: /usr/local/bin/node_exporter
cp -v /home/alex/scripts/nginx/node_exporter.service /etc/systemd/system
systemctl enable --now node_exporter.service
sleep 2
systemctl status node_exporter.service


echo ' Настройка репликации'
mysql -e "STOP SLAVE;"
sleep 1
mysql -e "CHANGE MASTER TO MASTER_HOST='110.20.1.63', MASTER_USER='repl', MASTER_PASSWORD='replREPL@', MASTER_LOG_FILE='binlog.000004', MASTER_LOG_POS=1006, GET_MASTER_PUBLIC_KEY = 1;"
sleep 1
mysql -e "START SLAVE;"
mysql -e "show slave status\G"
echo -e '0 10 * * * bash /home/alex/scripts/mysql_backup.sh' |  crontab -





