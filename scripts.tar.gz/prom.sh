#!/bin/bash
hostnamectl set-hostname ubuntu-prometheus

mkdir /home/alex/monitoring
echo 'Скачивание дистрибутивов'
wget -i /home/alex/scripts/prom/link.txt -P /home/alex/monitoring
echo 'Разархивирование'
tar -xvf /home/alex/monitoring/prometheus-2.37.9.linux-amd64.tar.gz -C /home/alex/monitoring
tar -xvf /home/alex/monitoring/node_exporter-1.6.1.linux-amd64.tar.gz -C /home/alex/monitoring
echo 'Создание пользователя prometheus'
useradd --no-create-home --shell /usr/bin/false prometheus
echo 'Создание пользователя node_exporter'
useradd --no-create-home --shell /usr/sbin/nologon node_exporter
echo 'Создание каталогов для prometheus'
mkdir -m 755 {/etc/,/var/lib/}prometheus
echo 'Копирование prometheus в системные каталоги'
cp -vr /home/alex/monitoring/prometheus-2.37.9.linux-amd64/prometheus.yml /home/alex/monitoring/prometheus-2.37.9.linux-amd64/consoles/ /home/alex/monitoring/prometheus-2.37.9.linux-amd64/console_libraries/ /etc/prometheus
cp -vr /home/alex/monitoring/prometheus-2.37.9.linux-amd64/prometheus /home/alex/monitoring/prometheus-2.37.9.linux-amd64/promtool /usr/local/bin
cp -v /home/alex/scripts/prom/prometheus.yml /etc/prometheus/
echo 'Изменение владельца'
chown -v -R prometheus: /usr/local/bin/prometheus
chown -v -R prometheus: /usr/local/bin/promtool
echo 'Копирование node_exporter в системные каталоги'
cp -vr /home/alex/monitoring/node_exporter-1.6.1.linux-amd64/node_exporter /usr/local/bin
echo 'Изменение владельца'
chown -v -R node_exporter: /usr/local/bin/node_exporter
chown -v -R prometheus: /var/lib/prometheus/
echo 'Старт prometheus'
cp -v /home/alex/scripts/prom/prometheus.service /home/alex/scripts/prom/node_exporter.service /etc/systemd/system
systemctl daemon-reload
systemctl enable --now prometheus.service 
systemctl enable --now node_exporter.service
echo 'Установка Grafana'
apt-get install -y adduser libfontconfig1
sleep 10
dpkg -i /home/alex/monitoring/grafana_10.1.0_amd64.deb
sleep 3
apt-get --fix-broken install -y 
sleep 3
systemctl enable --now grafana-server.service






