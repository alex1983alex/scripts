#!/bin/bash

echo 'Установка статического IP'
cat >/etc/netplan/00-installer-config.yaml <<EOL
network:
  ethernets:
    enp0s3:
      dhcp4: no
      addresses:
        - 110.20.1.66/24
      routes:
        - to: default
          via: 110.20.1.1
      nameservers:
        addresses:
          - 8.8.8.8
          - 1.1.1.1
  version: 2

EOL

echo 'Проверка конфигурации'
netplan try

echo 'Применение конфигурации'
netplan apply
echo 'Перезапуск службы '
systemctl restart system-networkd