#!/bin/bash

echo 'Установка имени сервера'
#cat >/etc/hostname <<EOL
#ubuntu-mysql-master
#EOL
hostnamectl set-hostname ubuntu-mysql-master

echo 'Установка mysql'
apt-get install mysql-server mysql-client --yes
cp -v /home/alex/scripts/mysql/mysqld1.cnf /etc/mysql/mysql.conf.d/mysqld.cnf

systemctl restart mysql.service

echo 'Создаём пользователя для реплики'
mysql -e "CREATE USER repl@'%' IDENTIFIED WITH 'caching_sha2_password' BY 'replREPL@';"
echo 'Даём пользователю repl права на репликацию'
mysql -e "GRANT REPLICATION SLAVE ON *.* TO repl@'%';"

echo 'Установка node_exporter'
wget https://github.com/prometheus/node_exporter/releases/download/v1.6.1/node_exporter-1.6.1.linux-amd64.tar.gz -P /home/alex/monitoring
tar -xvf /home/alex/monitoring/node_exporter-1.6.1.linux-amd64.tar.gz -C /home/alex/monitoring
useradd --no-create-home --shell /usr/sbin/nologon node_exporter
cp -vr /home/alex/monitoring/node_exporter-1.6.1.linux-amd64/node_exporter /usr/local/bin
chown -v -R node_exporter: /usr/local/bin/node_exporter
cp -v /home/alex/scripts/nginx/node_exporter.service /etc/systemd/system
systemctl enable --now node_exporter.service
sleep 2
systemctl status node_exporter.service

mysql -e "show master status;"





