#!/bin/bash

echo ' Создание новой базы данных'
mysql -e "CREATE USER 'wiki'@'%' IDENTIFIED BY 'Qwiker@';"
mysql -e "create database wiki_db;"
mysql -e "GRANT ALL ON wiki_db.* TO 'wiki'@'%';"
echo ' Разворачивание базы из бэкапа'
sudo mysql -u root wiki_db <  /home/alex/scripts/mysql/wiki_db.sql
mysql -e "use wiki_db; show tables;"






