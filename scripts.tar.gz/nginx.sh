#!/bin/bash

echo 'Установка имени сервера'
#cat >/etc/hostname <<EOL
#ubuntu-nginx
#EOL
hostnamectl set-hostname ubuntu-nginx

echo 'Установка nginx'
apt-get install nginx-full --yes

echo 'копирование конфигурации nginx '
cp /home/alex/scripts/nginx/default_nginx /etc/nginx/sites-available/default
echo 'Старт  nginx'
systemctl restart nginx.service
echo 'проверка состояния  nginx'
systemctl status nginx.service
echo 'Установка node_exporter'
wget https://github.com/prometheus/node_exporter/releases/download/v1.6.1/node_exporter-1.6.1.linux-amd64.tar.gz -P /home/alex/monitoring
tar -xvf /home/alex/monitoring/node_exporter-1.6.1.linux-amd64.tar.gz -C /home/alex/monitoring
useradd --no-create-home --shell /usr/sbin/nologon node_exporter
useradd --no-create-home --shell /usr/sbin/nologon nginx_exporter

cp -vr /home/alex/monitoring/node_exporter-1.6.1.linux-amd64/node_exporter /usr/local/bin
cp -vr /home/alex/scripts/nginx/nginx-prometheus-exporter /usr/local/bin

chown -v -R node_exporter: /usr/local/bin/node_exporter
chown -v -R nginx_exporter: /usr/local/bin/nginx-prometheus-exporter
chmod ugo+x /usr/local/bin/nginx-prometheus-exporter
 

cp -v /home/alex/scripts/nginx/node_exporter.service /etc/systemd/system
cp -v /home/alex/scripts/nginx/nginx_prometheus_exporter.service /etc/systemd/system

systemctl enable --now node_exporter.service
systemctl enable --now nginx_prometheus_exporter.service
sleep 5
systemctl status node_exporter.service
systemctl status nginx_prometheus_exporter.service




