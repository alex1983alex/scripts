#!/bin/bash


mysql -e "stop slave;"
mysqldump -uroot wiki_db > /home/alex/wiki_db-$(date +"%d-%m-%y-%H:%M:%S").sql
mysql -e "start slave;"






